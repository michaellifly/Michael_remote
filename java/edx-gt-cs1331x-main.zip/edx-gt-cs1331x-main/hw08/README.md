For this assignment, you will fill in the blanks of a nearly completed JavaFX program so that it functions as shown in the two images below:

<img src="https://lh5.googleusercontent.com/GcW8pbWhLlxb5-WlDlPbltrTdcYR8dyIeiXdzojc24l477lbQuBiqWHBlJ7m1iuIGGCBQpEosXEO1E0OcREnE6i1u6OkibW8ET8f4IZTN1Zftx9hgwcVyjndtMnimvWbKGHZv5v4">

<img src="https://lh6.googleusercontent.com/8FikQYO2lMBulRruxywSvy_y4nqplWT2kH3dh-2-yULHFhi089qt3obNcKy9idOSr-fAuuB73dIY05fCUEsuir_YtBWI8-j7O8muApIAdysR5jAQQClsijevw8lhf2SDqxWWlT7i">

As shown, the program converts a Dollar input value to its corresponding Pound value. Once the user clicks the Exchange button, the input value is converted and the Pound value is printed below the button. If the user inputs a non-numeric value, an error message is displayed.