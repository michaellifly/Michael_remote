public class Bad3 {
    public static void main(String[] args) {
        String letter = "a";
        System.out.println("letter is " + letter);
    }
}
