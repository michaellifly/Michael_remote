public class Bad1 {
    public static void main(String[] args) {
        String str = new String("CS1331ROCKS");
        System.out.println(str.length() - 5 + " is 11 - 5");
    }
}
